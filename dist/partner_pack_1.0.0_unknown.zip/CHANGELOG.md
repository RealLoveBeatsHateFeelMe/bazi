# Changelog

## Version 1.0.0 - 2025-12-17

**Git SHA**: `unknown`

### 变更摘要

### 详细变更

请参考 `BAZI_RULES.md`、`CODEMAP.md` 和 `API_CONTRACT.md` 获取详细变更说明。

---
