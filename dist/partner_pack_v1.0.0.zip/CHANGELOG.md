# Changelog

## Version 1.0.0 - 2025-12-16

### 新增功能

#### 线运加成（lineyun）
- **规则**：全年一次 +6%，且 active_pillar 的 pillar-impact ≥10 才触发
- **实现**：
  - 根据虚龄确定 active_pillar（0-16岁=年柱，17-32岁=月柱，33-48岁=日柱，49+岁=时柱）
  - 扫描所有 `role="base"` 事件，累加命中 active_pillar 的 `pillar_impact`（`position_weight * 100`）
  - 若累计 `pillar_impact >= 10.0`，则 `lineyun_bonus = 6.0`，直接加到 `total_risk_percent`
  - 全年最多只加一次，不叠加、不分干支
- **文档**：`BAZI_RULES.md` §3.3.2

#### 用神 explain 增强
- **功能**：用神 explain 按 final 用神计算；即使用神五行不在原局，也提供理论十神映射
- **实现**：
  - `yongshen_shishen` 统一按 `final_yongshen_elements` 计算
  - 对不在原局的用神五行，使用理论天干（木=甲乙、火=丙丁、土=戊己、金=庚辛、水=壬癸）推导十神
  - `yongshen_tokens` 只记录原局实际落点（可能为空）
- **文档**：`API_CONTRACT.md` §1.3

#### Special Rule：弱木强金补火
- **规则**：弱木（甲/乙日主，身弱 <50%）+ 强金（官杀%≥40%）+ 基础用神为水木 → 最终用神追加"火"
- **回归用例**：2005-08-08 08:00，断言 final 用神 = ["水","木","火"]
- **文档**：`BAZI_RULES.md`（special_rules 区域）

#### 六合/三合检测
- **功能**：检测原局和流年/大运的六合/三合组合
- **规则**：只解释，不计分（`risk_percent = 0`，不进入线运扫描，不影响 `total_risk_percent`）
- **输出**：
  - `analyze_basic` → `natal_harmonies: {"liuhe": [...], "sanhe": [...]}`
  - `analyze_luck` → 流年/大运的 `harmonies` 字段
- **文档**：`API_CONTRACT.md` §1.4、§2.3

### 字段统一

- **全仓统一字段名**：`ten_god` / `ten_gods` → `shishen` / `shishens`（方案B，破坏式改名）
- **函数名**：`get_branch_ten_god` 保留为兼容别名，推荐使用 `get_branch_shishen`

### 用神字段明确化

- **base/final 分离**：
  - `yongshen_detail.base_yongshen_elements`：原始计算出的基础用神
  - `yongshen_detail.final_yongshen_elements`：最终用神（包含 special_rules 补充）
  - 顶层 `yongshen_elements` == `detail.final_yongshen_elements` 永远一致
- **文档**：`API_CONTRACT.md` §1.1

### Schema 收紧

- **bazi 结构强制**：每个 pillar 必须有 `gan` 和 `zhi`（都 required）
- **positions 枚举**：
  - `pillar` enum: `["year","month","day","hour"]`
  - `kind` enum: `["gan","zhi"]`
- **required 字段扩展**：添加所有保证一定返回的字段
- **新增字段定义**：`natal_harmonies`、`base_yongshen_elements`、`final_yongshen_elements`

### 统一响应壳

- **新增**：`schemas/api_response.schema.json`
- **文档**：`API_CONTRACT.md` §0（统一响应壳）
- **结构**：`{ok: boolean, data: {basic, luck?}, error: null | {...}}`

### 回归测试

- **新增用例**：
  - `test_yongshen_special_rule_wood()`：2007-01-28 锁死 base/final 差异 + explain 走 final
  - `test_yongshen_special_rule_fire()`：2005-08-08 08:00 断言 final 用神 = ["水","木","火"]
- **覆盖**：刑规则 + traits T1/T2 + 用神 special_rules

### 文档更新

- `BAZI_RULES.md`：更新线运规则（§3.3.2）
- `CODEMAP.md`：更新线运、六合/三合说明
- `API_CONTRACT.md`：添加统一响应壳、用神 explain 说明、六合/三合字段说明
- `schemas/analyze_basic.schema.json`：收紧结构、添加新字段
- `schemas/api_response.schema.json`：新增响应壳 schema

---
